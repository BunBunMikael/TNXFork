/********************************************************************************
 * File: mod_funcs.hpp
 * Author: ppkantorski
 * Description:
 *   This header file contains function declarations and utility functions for IPS
 *   binary generations. These functions are used in the Ultrahand Overlay project
 *   to convert `.pchtxt` mods into `.ips` binaries.
 *
 *   For the latest updates and contributions, visit the project's GitHub repository.
 *   (GitHub Repository: https://github.com/ppkantorski/Ultrahand-Overlay)
 *
 *   Note: Please be aware that this notice cannot be altered or removed. It is a part
 *   of the project's documentation and must remain intact.
 * 
 *  Licensed under both GPLv2 and CC-BY-4.0
 *  Copyright (c) 2024-2026 ppkantorski
 ********************************************************************************/

#pragma once

#include <stdio.h>
#include <vector>
#include <string>
#include <sys/stat.h>
#include "debug_funcs.hpp"
#include "path_funcs.hpp"
#include "hex_funcs.hpp"
#include <iomanip> // Include this header for std::setw and std::setfill

namespace ult {
    inline constexpr const char* IPS32_HEAD_MAGIC = "IPS32";
    inline constexpr const char* IPS32_FOOT_MAGIC = "EEOF";

    /**
     * @brief Checks if a cheat already exists in the cheat file.
     * @param cheatFilePath The path to the cheat file.
     * @param newCheat The new cheat to check.
     * @return True if the cheat exists, otherwise false.
     */
    bool cheatExists(const std::string &cheatFilePath, const std::string &newCheat);
    
    /**
     * @brief Appends a new cheat to the cheat file.
     * @param cheatFilePath The path to the cheat file.
     * @param newCheat The new cheat to append.
     */
    void appendCheatToFile(const std::string &cheatFilePath, const std::string &newCheat);
    
    /**
     * @brief Extracts the cheat name from the given file path.
     * @param filePath The full file path.
     * @return The extracted cheat name.
     */
    std::string extractCheatName(const std::string &filePath);
    
    // Helper function to determine if a string is a valid title ID
    bool isValidTitleID(const std::string &str);
    
    // Function to find the title ID in the text, avoiding the @nsobid- line
    std::string findTitleID(const std::string &text);
    
    /**
     * @brief Converts a .pchtxt file to a cheat file.
     * @param pchtxtPath The file path to the .pchtxt file.
     * @param cheatName The name of the cheat.
     * @param outCheatPath The file path for the output cheat file.
     * @return True if the conversion was successful, false otherwise.
     */
    bool pchtxt2cheat(const std::string &pchtxtPath, std::string cheatName = "", std::string outCheatPath = "");

    // Corrected helper function to convert values to big-endian format
    inline uint32_t toBigEndian(uint32_t value) {
        return ((value & 0x000000FF) << 24) |
               ((value & 0x0000FF00) << 8)  |
               ((value & 0x00FF0000) >> 8)  |
               ((value & 0xFF000000) >> 24);
    }
    
    inline uint16_t toBigEndian(uint16_t value) {
        return ((value & 0x00FF) << 8) |
               ((value & 0xFF00) >> 8);
    }
    
    
    /**
     * @brief Converts a .pchtxt file to an IPS file using fstream.
     *
     * This function reads the contents of a .pchtxt file, extracts the address-value pairs,
     * and generates an IPS file with the provided output folder.
     *
     * @param pchtxtPath The file path to the .pchtxt file.
     * @param outputFolder The folder path for the output IPS file.
     * @return True if the conversion was successful, false otherwise.
     */
    bool pchtxt2ips(const std::string& pchtxtPath, const std::string& outputFolder);
}